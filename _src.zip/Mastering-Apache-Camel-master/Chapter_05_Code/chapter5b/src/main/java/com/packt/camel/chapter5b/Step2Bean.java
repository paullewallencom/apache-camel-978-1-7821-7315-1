package com.packt.camel.chapter5b;

public class Step2Bean {

    public static void single(String body) {
        System.out.println("STEP 2: " + body);
    }

}
