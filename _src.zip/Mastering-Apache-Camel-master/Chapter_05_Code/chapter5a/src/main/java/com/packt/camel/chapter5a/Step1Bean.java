package com.packt.camel.chapter5a;

public class Step1Bean {

    public static void single(String body) {
        System.out.println("STEP 1: " + body);
    }

}
